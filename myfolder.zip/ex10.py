"""10) Write a program to zip and unzip particular files."""

import zipfile

def zip_file():
    file_name = input("Enter file name to zip (with extension): ")
    zip_name = input("Enter name for zip file (without .zip): ")
    
    with zipfile.ZipFile(zip_name + ".zip", 'w') as zipf:
        zipf.write(file_name)
    
    print("File zipped successfully!")

zip_file()